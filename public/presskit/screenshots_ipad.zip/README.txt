Intake — iPad screenshots
https://getintake.de

Plain app screenshots without frame or copy, German and English, light and
dark. 2048 x 2732, iPad Air 13-inch, iOS 27.
heute (two columns), bibliothek (library), statistik (statistics), fasten
(fasting), add-food.

All material may be used for editorial coverage without asking first.
Contact: press@tobibechtold.dev
