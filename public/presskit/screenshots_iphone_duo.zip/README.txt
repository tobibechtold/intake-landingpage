Intake — iPhone Duo screenshots
https://getintake.de

Plain app screenshots without frame or copy, German and English, light and
dark, iOS 27, taken in the iPhone Duo simulator.

open/     The unfolded inner display, 2853 x 2007 (landscape): heute (two
          columns), heute-scrolled (activity with Apple Health, weight),
          bibliothek (library), statistik (statistics), add-food.
folded/   The outer display, 1398 x 2034 (portrait): heute, heute-expanded
          (all macros), statistik, add-food.

All material may be used for editorial coverage without asking first.
Contact: press@tobibechtold.dev
